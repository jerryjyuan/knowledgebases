# jw-angular-social-buttons

Angular 2+ Social Sharing Buttons

Demo and instructions available at http://jasonwatmore.com/post/2018/06/01/angular-2-social-sharing-buttons-for-facebook-google-plus-twitter-linkedin-and-pinterest