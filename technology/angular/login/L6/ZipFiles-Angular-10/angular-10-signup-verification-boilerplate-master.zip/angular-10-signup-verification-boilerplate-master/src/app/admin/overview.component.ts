﻿import { Component } from '@angular/core';

@Component({ templateUrl: 'overview.component.html' })
export class OverviewComponent { }