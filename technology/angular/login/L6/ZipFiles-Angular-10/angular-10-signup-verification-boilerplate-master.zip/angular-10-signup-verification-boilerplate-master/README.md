# angular-10-signup-verification-boilerplate

Angular 10 Boilerplate - Email Sign Up with Verification, Authentication & Forgot Password

For documentation and a live demo see https://jasonwatmore.com/post/2020/08/29/angular-10-boilerplate-email-sign-up-with-verification-authentication-forgot-password
