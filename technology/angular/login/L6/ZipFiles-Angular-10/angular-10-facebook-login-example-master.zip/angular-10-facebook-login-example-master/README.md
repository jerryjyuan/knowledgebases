# angular-10-facebook-login-example

Angular 10 - Facebook Login Example

Tutorial and demo available at https://jasonwatmore.com/post/2020/09/21/angular-10-facebook-login-tutorial-example