﻿export class Account {
    id: string;
    facebookId: string;
    name: string;
    extraInfo: string;
    token?: string;
}