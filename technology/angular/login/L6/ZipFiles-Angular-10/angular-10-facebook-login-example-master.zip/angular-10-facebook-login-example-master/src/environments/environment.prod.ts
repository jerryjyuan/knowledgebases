export const environment = {
    production: true,
    apiUrl: 'http://localhost:4000',
    facebookAppId: '314930319788683'
};
