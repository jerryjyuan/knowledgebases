# jw-angular-pagination

Angular Pagination Component

Usage instructions available at https://jasonwatmore.com/post/2018/04/26/npm-jw-angular-pagination-component