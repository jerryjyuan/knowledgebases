/*
 * Public API Surface of jw-pagination
 */

export * from './lib/jw-pagination.component';
export * from './lib/jw-pagination.module';
