# angular-8-animation-example

Angular 8 Router Animation Tutorial & Example

For a demo and further details see https://jasonwatmore.com/post/2019/11/04/angular-8-router-animation-tutorial-example