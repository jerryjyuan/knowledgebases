# angular-10-custom-modal

Angular 10 - Custom Modal Example

Tutorial and demo available at https://jasonwatmore.com/post/2020/09/24/angular-10-custom-modal-window-dialog-box