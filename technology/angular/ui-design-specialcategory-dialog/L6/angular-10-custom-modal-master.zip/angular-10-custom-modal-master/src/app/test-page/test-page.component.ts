﻿import { Component } from '@angular/core';

@Component({ templateUrl: 'test-page.component.html' })
export class TestPageComponent { }