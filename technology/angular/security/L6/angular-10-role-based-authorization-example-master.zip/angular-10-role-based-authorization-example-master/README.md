# angular-10-role-based-authorization-example

Angular 10 - Role Based Authorization Example

To see a demo and further details go to https://jasonwatmore.com/post/2020/09/09/angular-10-role-based-authorization-tutorial-with-example