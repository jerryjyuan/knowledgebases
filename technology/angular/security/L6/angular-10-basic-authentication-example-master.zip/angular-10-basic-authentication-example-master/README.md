# angular-10-basic-authentication-example

Angular 10 - Basic HTTP Authentication Example

To see a demo and further details go to https://jasonwatmore.com/post/2020/10/17/angular-10-basic-http-authentication-tutorial-example