# node-jwt-authentication-api

NodeJS JWT Authentication API

For documentation and instructions check out https://jasonwatmore.com/post/2018/08/06/nodejs-jwt-authentication-tutorial-with-example-api
