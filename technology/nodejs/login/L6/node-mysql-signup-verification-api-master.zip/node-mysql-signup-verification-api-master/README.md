# node-mysql-signup-verification-api

NodeJS + MySQL - Boilerplate API with Email Sign Up, Verification, Authentication & Forgot Password

For documentation and instructions see https://jasonwatmore.com/post/2020/09/08/nodejs-mysql-boilerplate-api-with-email-sign-up-verification-authentication-forgot-password